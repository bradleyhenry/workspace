package gcf;

public class GcfRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Gcf w = new Gcf();
	}

}
