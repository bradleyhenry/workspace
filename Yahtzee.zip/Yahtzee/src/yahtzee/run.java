package yahtzee;

public class run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		GUI w = new GUI();
	}

}
